import React from "react";
import { Link } from 'react-router-dom'


function Navigation () {
    return (
        <article className="App-nav">
        <div class="App-nav">
        <Link to="/"><a href="/">Home</a></Link>
        <Link to="/add-exercise"><a href="/add-exercise">Add Exercise</a></Link>
      </div> 
      </article>
    );
}

export default Navigation;